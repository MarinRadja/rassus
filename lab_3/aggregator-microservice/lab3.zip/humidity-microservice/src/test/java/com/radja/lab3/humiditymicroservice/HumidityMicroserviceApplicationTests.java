package com.radja.lab3.humiditymicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HumidityMicroserviceApplicationTests {

    @Test
    void contextLoads() {
    }

}
