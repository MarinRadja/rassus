package com.radja.temperaturemicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TemperatureMicroserviceApplicationTests {

    @Test
    void contextLoads() {
    }

}
